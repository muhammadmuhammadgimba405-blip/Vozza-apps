# VOZZA Workers API plan

Public:
GET /feed
GET /search
GET /reels/:id
GET /voice/:id
GET /products/:id
GET /profiles/:username

Authenticated:
POST /reels
POST /voice
POST /comments
POST /likes
DELETE /likes
POST /saves
POST /gifts
POST /follows
POST /stories
POST /groups
POST /products
POST /cart
POST /orders
POST /payments/initialize
POST /payments/verify
POST /referrals/track
POST /withdrawals
DELETE /content/:id
DELETE /account

Webhook:
POST /webhooks/paystack

Security rules:
- authenticate protected endpoints
- check ownership before edit/delete
- validate media type/size/duration
- R2 stores media; D1 stores metadata
- verify Paystack server-side
- webhook processing is idempotent
- never trust client-side price, balance, like count or earnings
- unique constraints enforce one like per user/content
- rate-limit engagement/payment endpoints
- audit financial/security actions
