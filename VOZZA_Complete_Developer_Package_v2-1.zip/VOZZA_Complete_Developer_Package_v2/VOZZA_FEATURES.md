# VOZZA — COMPLETE DEVELOPER SPECIFICATION v2

## 0. Core architecture
VOZZA mobile app
-> Cloudflare Workers (backend/API)
-> Cloudflare D1 (database)
-> Cloudflare R2 (media)
-> Paystack (payments)

The developer must build the actual mobile UI, backend, authentication, authorization,
media upload/playback, offline synchronization, moderation, notifications, payment
verification, testing and deployment. D1/R2/Paystack are infrastructure, not the app.

Never put Paystack secret keys in the client. Never trust client-side balances, prices,
like counts or earnings.

## 1. Accounts and profiles
- Email signup/login
- Google sign-in
- Password reset
- Logout
- Account deletion
- Profile photo
- Display name, username and bio
- Country and country flag
- Optional public country/location label
- Online green indicator with privacy control
- Followers/following
- Block/report
- Privacy, security, notification, language and data-saver settings

## 2. Public viewing and authentication rules
Anyone can view public Reel and Voice content without signing in.
Sign-in is required to:
- like
- gift
- buy
- comment
- save
- follow
- upload
- create stories/groups/products
- sell
- participate in creator earnings

## 3. Reel
- Record/upload video
- Maximum 30 seconds
- Caption
- Category
- @mentions
- View count
- Like
- Text comment
- 20-second voice comment
- Share
- Save
- Gift
- Report
- Delete own Reel
- Draft
- WhatsApp/device share
- Shareable Reel URL
- R2 media + D1 metadata
- One like per user per Reel
- Server-side validation/rate limiting
- Anti-fake engagement

## 4. Voice
- Record/upload audio
- Maximum 60 seconds
- Caption/category/@mentions
- View/play count
- Like
- Text comment
- 20-second voice comment
- Share
- Save
- Gift
- Report
- Delete own Voice
- Draft
- WhatsApp/device share
- Shareable Voice URL
- 10 configurable voice-effect presets
- R2 audio + D1 metadata
- One like per user per Voice
- Server-side validation/rate limiting
- Anti-fake engagement
- Voice effects must not be used for impersonation/fraud

## 5. Search and discovery
- Search bar
- Search Reels
- Search Voice
- Search products
- Search users
- Categories: New, Comedy, Culture and admin-configurable categories
- Trending
- Recommended feed
- Pagination/infinite scroll

## 6. Status / Story
- 24-hour stories/status
- Text
- Photo
- Video
- Optional voice story
- Text + media combination
- Audience/privacy settings
- Delete own story
- Admin/moderation removal
- Story views

## 7. Groups
- User-created groups
- Group name, image, description
- Public/private
- Admin/moderators
- Join/leave
- Member management
- Admin approval for stories/posts
- Group reports/moderation
- Optional public display-name hiding where allowed
- Internal audit always retains the real account identity

## 8. Comments
- Text comments
- Voice comments maximum 20 seconds
- Like/report
- Delete own comment
- @mentions
- Anti-spam/rate limits
- Moderation

## 9. Marketplace
- Seller registration
- Product creation
- Product images
- Product video
- Price
- Currency
- Stock
- Description
- Category
- Product search
- Product share link
- Product page
- Cart
- Checkout
- Orders
- Buyer order history
- Seller order dashboard
- Seller sales dashboard
- Product reports
- Seller trust history

## 10. Product share / Buy link
Every product gets a unique public URL, for example:
vozza.app/buy/{productId}

The link can be shared to WhatsApp, Facebook, SMS and other device share targets.

When opened:
- show product photo/video
- show product price/currency
- show seller
- show trust information allowed by privacy rules
- show Reel/Voice product content where available
- show Buy button
- allow sign-in/signup
- start Paystack checkout
- create order only after verified payment

This is DIFFERENT from content sharing:
A Reel/Voice link opens the content.
A product Buy link opens the product purchase page.

## 11. Referral / owner reward
Implement a configurable referral system for product links.

Requested business rule:
- If a referred buyer purchases a product through a qualifying referral link,
  the referring owner receives 5% of the qualifying commission/base defined by the
  admin configuration.

IMPORTANT:
Do not silently assume that “5%” means 5% of the entire product price in every market.
Make:
- referral rate
- qualifying base
- eligible products
- attribution window
- maximum/minimum referral reward
configurable in Admin.

Referral attribution must be server-side and resistant to self-referrals and fraud.

Store:
- referral code/link
- referrer
- buyer
- product
- order
- qualifying amount
- referral reward
- status
- timestamps

## 12. Paystack
- Server-side payment initialization
- Paystack checkout
- Server-side verification
- Webhooks
- Idempotent webhook handling
- Payment success/failure/cancel states
- Refund/dispute workflow
- Transaction ledger
- Platform commission target: 10% (configurable)
- Referral reward target: 5% (configurable)
- Never store raw card details
- Never expose secret key in mobile app

## 13. Creator earnings
Target qualification:
- 50,000 followers AND
- 200,000 eligible likes in a month

Target reward:
- ₦200 per 1,000 eligible likes

Make thresholds/rates configurable in Admin.

Creator dashboard:
- followers
- eligible monthly likes
- qualification progress
- reward calculator
- gifts received
- product sales
- total earnings
- pending balance
- available balance
- transaction history
- withdrawal status

Automatic monthly calculation:
- count eligible likes server-side
- one like per user/content
- exclude self-like
- detect suspicious/fake engagement
- reverse fraudulent rewards
- immutable earnings ledger

## 14. Gifts
Requested values:
- 200
- 500
- 1,000
- 1,500
- 2,000
- 5,000
- 7,000

Make gift catalog, prices, currencies and creator share configurable.
Every gift creates a transaction/ledger record.

## 15. Currency
- Nigeria: NGN/₦
- United States: USD/$
- Other supported countries: configured local currency
- Dashboard shows user's supported currency
- Store original transaction currency/amount
- If conversion is required, calculate server-side from a reliable rate source
- Never trust client-side conversion

## 16. Withdrawals
- Creator/seller withdrawal request
- Configurable minimum
- Requested examples: ₦1,500 Nigeria and $1 in some markets
- pending/processing/paid/failed/reversed
- audit trail
- KYC/compliance where required
- fraud/risk review

## 17. Verified badge
- Eligible creators can receive a creator/verified badge according to platform rules
- Badge stored server-side
- Admin can revoke
- Do not call it government identity verification unless identity was actually verified

## 18. Supplies / supplier network
Build a supplier relationship and supply history module:
- supplier profiles
- supplier contact/reference information
- products supplied
- seller/supplier relationships
- supply events
- availability/stock history
- fulfillment history
- supplier performance/trust events
- transaction history between marketplace participants where legally appropriate
- internal supplier notes
- admin-only sensitive supplier information
- supplier status: active/inactive/review

The supplier network is intended as a long-term business moat. Do not expose private supplier information publicly.

## 19. Transaction history
Maintain server-side immutable ledgers for:
- purchases
- seller sales
- platform commissions
- creator rewards
- gifts
- referral rewards
- withdrawals
- refunds
- reversals
- payment events

Every financial event should have:
- unique ID
- user/account
- order/content/reference
- original amount
- currency
- type
- status
- timestamp
- provider reference where applicable

Never edit financial history directly; use reversal/correction events.

## 20. Trust history
Build internal trust signals for:
- buyer
- seller
- creator
- supplier

Signals may include:
- completed orders
- cancelled orders
- refunds
- disputes
- verified payments
- delivery/fulfillment history
- confirmed sales
- reports
- fraud flags
- account age
- successful transactions

Do not expose sensitive fraud signals publicly. Show only safe trust indicators.

## 21. Offline / low-data
- cache previously viewed eligible content
- offline Reel/Voice drafts
- upload queue
- retry after reconnect
- sync status
- duplicate prevention
- data saver
- local cache/database
- never mark offline payment successful

## 22. Anti-fake engagement
- database uniqueness: user + content
- one like per content per user
- server-side authorization
- rate limiting
- suspicious engagement detection
- quarantine/review
- reward reversal
- anti-bot controls
- audit logs

Do not promise perfect fraud detection.

## 23. Notifications
- likes
- comments
- follows
- gifts
- sales
- purchases
- payment status
- referral rewards
- creator earnings
- withdrawals
- group approvals
- moderation
- system notices

## 24. Admin dashboard
- users
- profiles
- Reels
- Voice
- stories
- groups
- comments
- reports
- sellers
- suppliers
- products
- orders
- payments
- gifts
- creator earnings
- referral rewards
- withdrawals
- badges
- categories
- voice effects
- commissions
- monetization rules
- referral rules
- country/currency settings
- fraud flags
- moderation
- audit logs
- analytics

## 25. Database entities
Recommended D1 tables:
users
profiles
countries
sessions
follows
reels
voice_posts
media_files
comments
comment_voice_files
likes
saves
gifts
gift_catalog
stories
story_views
groups
group_members
group_posts
group_moderation
seller_profiles
suppliers
supplier_products
supplier_relationships
supplier_trust_events
products
product_media
carts
cart_items
orders
order_items
payments
payment_events
referral_codes
referrals
referral_rewards
creator_eligibility
creator_earnings
earnings_ledger
withdrawals
seller_trust_events
reports
blocks
notifications
categories
voice_effects
audit_logs
fraud_events
app_settings

## 26. Media
R2 stores:
- Reel videos
- Voice audio
- voice-comment audio
- story media
- profile images
- product images/video

D1 stores metadata:
- owner
- media type
- object key
- permissions
- content relationship
- timestamps
- duration
- moderation status

Use signed/private URLs when content is not public.

## 27. Backend/API
Suggested Worker endpoints:
GET /feed
GET /search
GET /reels/:id
GET /voice/:id
GET /products/:id
GET /profiles/:username
POST /reels
POST /voice
POST /comments
POST /likes
DELETE /likes
POST /saves
POST /gifts
POST /follows
POST /stories
POST /groups
POST /products
POST /cart
POST /orders
POST /payments/initialize
POST /payments/verify
POST /referrals/track
POST /withdrawals
DELETE /content/:id
DELETE /account
POST /webhooks/paystack

## 28. Payment example
BUY:
1. User taps Buy.
2. Worker checks product/stock/price from D1.
3. Worker creates pending order.
4. Worker initializes Paystack transaction.
5. Customer pays.
6. Paystack sends event.
7. Worker verifies event.
8. Worker marks payment/order as paid.
9. Seller sees the order.
10. Platform commission is ledgered.
11. If referral qualifies, referral reward is ledgered.
12. Buyer and seller transaction history is updated.

## 29. Upload example
1. User records Reel/Voice.
2. App requests authorized upload.
3. Worker validates user and metadata.
4. Media uploads to R2.
5. Worker/D1 records metadata.
6. Moderation/status is applied.
7. Feed can return the content.
8. If offline, store draft locally and sync later.

## 30. Navigation
Home | Search | Create | Activity | Profile

Create:
Reel | Voice | Story | Product

Profile:
Reels | Voice | Products | Followers | Following | Earnings

## 31. UI
Use a recognizable VOZZA identity.
Requested direction:
- African-inspired color identity
- clean modern marketplace/social layout
- large media cards
- simple two-tap access to Reel and Voice
- prominent Buy/share controls
- accessible text/buttons
- data-saving controls

## 32. Account/settings
- Profile
- Privacy
- Security
- Notifications
- Language
- Country
- Currency
- Data saver
- Offline settings
- Blocked users
- Payments
- Earnings
- Withdrawals
- Delete account
- Terms
- Privacy policy
- Help/report

## 33. Testing acceptance
Test every feature with:
- logged-out user
- logged-in user
- new account
- creator
- buyer
- seller
- supplier/admin
- slow network
- offline/reconnect
- duplicate requests
- failed payment
- successful payment
- refund
- webhook retry
- multiple devices
- Android
- iOS if supported
- permission/security tests
- moderation tests

Production readiness requires actual testing. No specification can honestly guarantee a bug-free app before implementation and testing.
