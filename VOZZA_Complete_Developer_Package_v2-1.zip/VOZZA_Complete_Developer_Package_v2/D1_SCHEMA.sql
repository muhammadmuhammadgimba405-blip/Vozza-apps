-- VOZZA D1 starter schema
CREATE TABLE IF NOT EXISTS users(
 id TEXT PRIMARY KEY,email TEXT UNIQUE,country_code TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS profiles(
 user_id TEXT PRIMARY KEY,display_name TEXT,username TEXT UNIQUE,bio TEXT,
 country_code TEXT,country_flag TEXT,avatar_key TEXT,verified INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS follows(
 follower_id TEXT NOT NULL,following_id TEXT NOT NULL,created_at TEXT NOT NULL,
 PRIMARY KEY(follower_id,following_id));
CREATE TABLE IF NOT EXISTS reels(
 id TEXT PRIMARY KEY,owner_id TEXT NOT NULL,media_key TEXT NOT NULL,caption TEXT,
 category TEXT,duration_seconds INTEGER NOT NULL CHECK(duration_seconds<=30),created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS voice_posts(
 id TEXT PRIMARY KEY,owner_id TEXT NOT NULL,media_key TEXT NOT NULL,caption TEXT,
 category TEXT,duration_seconds INTEGER NOT NULL CHECK(duration_seconds<=60),effect_id TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS likes(
 user_id TEXT NOT NULL,content_type TEXT NOT NULL,content_id TEXT NOT NULL,created_at TEXT NOT NULL,
 PRIMARY KEY(user_id,content_type,content_id));
CREATE TABLE IF NOT EXISTS comments(
 id TEXT PRIMARY KEY,user_id TEXT NOT NULL,content_type TEXT NOT NULL,content_id TEXT NOT NULL,
 body TEXT,voice_key TEXT,voice_duration_seconds INTEGER,
 CHECK(voice_duration_seconds IS NULL OR voice_duration_seconds<=20));
CREATE TABLE IF NOT EXISTS products(
 id TEXT PRIMARY KEY,seller_id TEXT NOT NULL,name TEXT NOT NULL,description TEXT,
 price_minor INTEGER NOT NULL,currency TEXT NOT NULL,stock INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS orders(
 id TEXT PRIMARY KEY,buyer_id TEXT NOT NULL,seller_id TEXT NOT NULL,status TEXT NOT NULL,
 total_minor INTEGER NOT NULL,currency TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS payments(
 id TEXT PRIMARY KEY,order_id TEXT NOT NULL,provider TEXT NOT NULL,
 provider_reference TEXT UNIQUE,status TEXT NOT NULL,amount_minor INTEGER NOT NULL,
 currency TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS referral_codes(
 id TEXT PRIMARY KEY,owner_id TEXT NOT NULL,code TEXT UNIQUE,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS referrals(
 id TEXT PRIMARY KEY,code_id TEXT NOT NULL,referrer_id TEXT NOT NULL,buyer_id TEXT,
 product_id TEXT,order_id TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS referral_rewards(
 id TEXT PRIMARY KEY,referral_id TEXT NOT NULL,rate_bps INTEGER NOT NULL,
 base_minor INTEGER NOT NULL,reward_minor INTEGER NOT NULL,currency TEXT NOT NULL,
 status TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS creator_earnings(
 id TEXT PRIMARY KEY,user_id TEXT NOT NULL,period TEXT NOT NULL,
 eligible_followers INTEGER NOT NULL DEFAULT 0,eligible_likes INTEGER NOT NULL DEFAULT 0,
 reward_minor INTEGER NOT NULL DEFAULT 0,currency TEXT NOT NULL,status TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS gifts(
 id TEXT PRIMARY KEY,sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,
 amount_minor INTEGER NOT NULL,currency TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS earnings_ledger(
 id TEXT PRIMARY KEY,user_id TEXT NOT NULL,type TEXT NOT NULL,amount_minor INTEGER NOT NULL,
 currency TEXT NOT NULL,reference_id TEXT,created_at TEXT NOT NULL);
